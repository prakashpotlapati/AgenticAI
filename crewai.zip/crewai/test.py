from crewai import Agent, Task,LLM
from langchain_groq import ChatGroq
import os
# from dotenv import load_dotenv
import json

from prompts import coverage_type_prompt,coverage_type_expected_out,prompt,expected_out

# Load environment variables
# load_dotenv()

# Initialize Groq LLM
# groq_llm = ChatGroq(
#     temperature=0.1,
#     model_name="groq/mixtral-8x7b-32768",  # or "llama2-70b-4096"
#     api_key= "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"
# )

# groq_llm = LLM()
os.environ["GROQ_API_KEY"] = "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"
groq_llm = LLM(model="groq/llama-3.3-70b-versatile")
# Create a file reading tool
from crewai.tools import tool

@tool("File Reader Tool")
def file_reader(file_path: str) -> str:
    """Reads and returns content from a text file"""
    with open(file_path, 'r') as file:
        return file.read()

@tool("Excel Reader Tool")
def excel_reader(excel_file_path: str) -> str:
    """Reads and returns content from an Excel file as CSV formatted string"""
    try:
        import pandas as pd
        df = pd.read_excel(file_path)
        return df.to_csv(index=False)
    except Exception as e:
        return f"Error reading Excel file: {e}"

# Create the coverage extraction agent
coverage_agent = Agent(
    role='Insurance Coverage Analyst',
    goal='Accurately extract coverage type values from insurance documents',
    backstory="""You're an expert in analyzing insurance documents with years of 
    experience identifying coverage types and policy details from complex texts.""",
    verbose=True,
    tools=[file_reader],
    llm=groq_llm,
    max_iter=3
)

loss_extraction_agent = Agent(
    role='Insurance Data Analyst',
    goal='Analyze Excel data in context of insurance coverage information',
    backstory="""Expert in correlating insurance coverage details with operational data from Excel files.""",
    verbose=True,
    tools=[excel_reader],
    llm=groq_llm,
    max_iter=3
)

# Create the extraction task
coverage_extraction_task = Task(
    description= coverage_type_prompt(),
    expected_output=coverage_type_expected_out(),
    agent=coverage_agent,
    output_file="coverage_result.json"
)

data_analysis_task = Task(
    description=lambda context: prompt(context['coverage_info']),
    expected_output=expected_out(),
    agent= loss_extraction_agent,
    context=[coverage_extraction_task],  # Creates dependency chain
    output_file="data_analysis.json"
)

# Execute the task
def extract_coverage(file_path: str):
    context = {"file_path": file_path}
    result = coverage_agent.execute_task(coverage_extraction_task, context)
    
    try:
        # Parse the JSON output
        coverage_data = json.loads(result)
        return coverage_data
    except json.JSONDecodeError:
        return {"error": "Failed to parse coverage information"}



# Updated Crew Execution
def analyze_insurance_documents(text_path: str, excel_path: str):
    # Execute coverage extraction first
    coverage_result = coverage_extraction_task.execute(context={"file_path": text_path})
    
    try:
        # Parse the JSON output for validation
        coverage_info = json.loads(coverage_result)
    except json.JSONDecodeError:
        raise ValueError("Failed to parse coverage information")

    # Execute data analysis with parsed coverage info
    return data_analysis_task.execute(context={
        "excel_file_path": excel_path,
        "coverage_info": coverage_info  # Pass the parsed dictionary
    })

# # Usage
# if __name__ == "__main__":
#     file_path = "test.txt"  # Replace with your file path
#     coverage_info = extract_coverage(file_path)

#     print(f"Extracted Coverage Type: {coverage_info}")


# Main Execution
if __name__ == "__main__":
    text_file = "test.txt"
    excel_file = "data.xlsx"
    
    try:
        # Get coverage info
        coverage_result = coverage_extraction_task.execute(context={"file_path": text_file})
        coverage_info = json.loads(coverage_result)
        
        # Execute data analysis with actual dictionary
        analysis_result = data_analysis_task.execute(context={
            "excel_file_path": excel_file,
            "coverage_info": coverage_info
        })
        
        print("Coverage Information:")
        print(json.dumps(coverage_info, indent=2))
        print("\nData Analysis:")
        print(json.dumps(json.loads(analysis_result), indent=2))
        
    except Exception as e:
        print(f"Error: {str(e)}")