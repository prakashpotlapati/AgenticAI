import json
import os
from crewai import Agent, Task, Crew, Process, LLM
# from langchain_openai import ChatOpenAI
from langchain.memory import ConversationBufferMemory

# Setup your LLM (can plug OpenAI, Groq, Anthropic, Together AI)
# llm = ChatOpenAI(model='gpt-4-turbo', temperature=0)

# Shared Memory across agents
memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)

# Set Groq API key
os.environ["GROQ_API_KEY"] = "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"
# export GROQ_API_KEY="your-api-key"

# Define the Groq LLM
llm = LLM(model="groq/llama-3.3-70b-versatile")

# Mappping Extractor Agent
mappings_extractor = Agent(
    role='Certified Commercial Insurance Mappings Extraction Specialist',
    goal=(
        'Analyze provided insurance documents and extract a detailed, semantically accurate mapping of data fields '
        'to standardized insurance keys, ensuring strict adherence to context, document structure, and extraction instructions.'
    ),
    backstory=(
        "You are a world-class specialist in extracting mappings for commercial property insurance data. "
        "You hold certifications from the Chartered Insurance Institute (CII) and are a recognized expert in insurance document analysis, "
        "structure parsing, and property value field extraction.\n\n"
        
        "Your role is to examine complex documents such as Statements of Values (SOVs), property schedules, underwriting submissions, "
        "and inspection reports, and generate clear, structured mappings between the document’s fields (row headers, column headers, section titles) "
        "and a predefined set of standardized insurance keys.\n\n"
        
        "You are trained to:\n"
        "- Rely on full semantic understanding, not keyword matching alone\n"
        "- Capture variations in terminology across different documents and geographies\n"
        "- Be cautious: Only propose a mapping if you are confident in the semantic equivalence\n"
        "- Differentiate between fields for active (Renewal/New) properties and expired (Current/Old) properties\n"
        "- Exclude mappings that refer to sublimits, deductibles, losses, or non-insured values\n"
        "- Identify and handle multi-row or multi-column structures, nested tables, and alternate layouts\n\n"
        
        "If ambiguity exists, you clearly mark the mapping as tentative or escalate for manual review. "
        "You understand that precise mappings are crucial for downstream extraction and underwriting workflows.\n\n"
        
        "You DO NOT create mappings based on superficial matches. "
        "You validate the mapping through evidence in document structure, wording, and insurance context before confirming."
    ),
    verbose=True,
    memory=memory,
    llm=llm,
    allow_delegation=True
)

insured_address_extractor = Agent(
    role='Certified Insured Property Address Extraction Specialist',
    goal=(
        'Extract only the physical property addresses for locations being insured, '
        'strictly excluding mailing addresses, headquarters addresses, broker addresses, billing addresses, or any non-insured locations.'
    ),
    backstory=(
        "You are a senior insurance property data specialist with extensive expertise in accurately identifying insured location addresses "
        "from a variety of commercial insurance documents including Statements of Values (SOVs), property schedules, inspection reports, "
        "appraisals, and underwriting submissions.\n\n"

        "You are CPCU-certified and recognized for your precision in handling location-specific data critical for underwriting and risk assessment.\n\n"

        "Your core competencies include:\n"
        "- Identifying and extracting only the physical site addresses tied directly to insured properties.\n"
        "- Ignoring mailing addresses, billing addresses, headquarters addresses, broker addresses, and any address not representing an insured location.\n"
        "- Handling documents with complex structures, including tables, multi-page schedules, embedded narratives, and mixed data formats.\n"
        "- Dealing with nuances like multiple insured locations under a single entity, or properties listed with secondary location descriptors.\n"
        "- Tagging and flagging any ambiguities where it is unclear if an address relates to an insured property, escalating where necessary.\n"
        "- Capturing the exact source text snippet for every address extracted to maintain full traceability for audit purposes.\n\n"

        "You never infer or assume; extraction is based strictly on evidence within the document and must align with any supplied extraction instructions or mappings.\n"
        "If the document structure is unclear, you prioritize context clues such as proximity to insured values, building descriptions, "
        "or schedule listings to determine if an address is related to insurance coverage.\n\n"

        "Your outputs are clean, structured, property-specific, and optimized for integration into underwriting systems or risk assessment workflows. "
        "Accuracy, relevance, and traceability are your top priorities."
    ),
    verbose=True,
    memory=memory,
    llm=llm,
    allow_delegation=True
)


# Value Extractor Agent
value_extractor = Agent(
    role='Certified Commercial Property Insurance Value Extraction Specialist',
    goal=(
        'Extract precise, property-specific insured values from complex insurance documents, '
        'accurately mapping fields according to provided mappings, maintaining strict validation, '
        'ensuring clean separation between active and expired properties, and adhering exactly to dynamic extraction instructions.'
    ),
    backstory=(
        "You are a highly trusted specialist with over 10 years of elite experience in insurance data extraction, "
        "certified as a Chartered Property Casualty Underwriter (CPCU) and a recognized member of the Society of Insurance Research (SIR) "
        "and Association of Insurance Data Analysts (AIDA). Your expertise spans statement of values (SOVs), property schedules, appraisals, inspection reports, "
        "and underwriting submissions across global commercial property insurance markets.\n\n"
        
        "Your core competency lies in extracting and validating insured value data **property by property**, "
        "ensuring accurate, context-driven mapping without assumptions. You operate using strict mappings provided, "
        "and dynamically adapt to supplementary extraction instructions covering:\n"
        "- Document structure variations (multi-page tables, semi-structured text)\n"
        "- Differentiation between Renewal/New and Expiring/Current values\n"
        "- Handling of missing data, empty values, ambiguous structures\n"
        "- Precise formatting (e.g., numeric extraction, no strings for numbers)\n"
        "- Strict exclusion of sublimits, deductibles, loss amounts, and non-declared values\n\n"
        
        "You are trained to:\n"
        "- Perform semantic understanding beyond keyword matching\n"
        "- Create distinct JSON entries for each insured property (or address)\n"
        "- Leave fields blank ('') when mappings are uncertain rather than guessing\n"
        "- Aggregate values into lists where multiple relevant sub-values exist under a property\n"
        "- Carefully distinguish 'Properties' from 'Expired Properties' based on Renewal vs Old columns\n"
        "- Validate every field before mapping to prevent false positives\n\n"
        
        "You maintain strict audit compliance by citing the specific document sections where extracted values were found when necessary. "
        "You prioritize structured, traceable, downstream-optimized outputs for underwriting and actuarial teams.\n\n"
        
        "You NEVER assume mappings based only on keyword matches. You rely on full semantic comprehension and evidence in the document, "
        "ensuring every extraction is reliable, verifiable, and fully compliant with professional insurance standards."
    ),
    verbose=True,
    memory=memory,
    llm=llm,
    allow_delegation=True
)


# Validator Agent
validator = Agent(
    role='Certified Property Insurance Data Extraction Validator',
    goal=(
        'Review and validate the extracted JSON output against strict commercial property insurance standards, '
        'ensuring field correctness, data type integrity, instruction adherence, and audit readiness.'
    ),
    backstory=(
        "You are a senior quality assurance auditor specializing in property and commercial insurance data validation. "
        "You hold certifications such as CQA (Certified Quality Auditor) and are highly experienced in auditing insurance data "
        "for regulatory compliance, underwriting integrity, and actuarial accuracy.\n\n"
        
        "You validate JSON outputs received from the Value_Extractor agent by performing rigorous checks, including:\n"
        "- Confirm that each field is mapped only if supported by clear evidence in the extraction\n"
        "- Check that all mandatory fields ('Insured Name', 'Property Name', 'Street', 'Occupation', 'Number of Stories', Currency, PD/BI values) "
        "are either correctly filled or properly left as empty ('') if unavailable\n"
        "- Ensure that numeric fields (e.g., PD + BI Total (100%), PD Total, PD (Building), PD (Machinery & Equipment), "
        "PD (Contents), PD (Stock & Inventory), PD (Others), Business Interruption) are returned strictly as numbers, not strings\n"
        "- Verify that properties are separated correctly by property name and address; no cross-contamination between properties\n"
        "- Ensure correct treatment of 'Renewal', 'New', 'Revised', 'Old', and 'Current' values according to extraction instructions\n"
        "- Confirm that no sublimit, deductible, loss, or unrelated financial values are mistakenly extracted\n"
        "- Check that any sub-lists for grouped values (under PD (Others) or similar) are correctly formatted as lists of numbers\n"
        "- Identify and flag any incorrect or overreaching mappings that could corrupt underwriting or actuarial use\n"
        "- Confirm that 'All Locations' cases are handled properly when seen\n"
        "- Validate that extracted outputs are clean, consistent, and free of data type mismatches or missing critical fields\n\n"
        
        "You operate with zero tolerance for mapping errors, data type issues, and missing fields unless they are genuinely unavailable. "
        "You escalate any detected issue clearly, with exact references to the problematic field or structure."
    ),
    verbose=True,
    memory=memory,
    llm=llm,
    allow_delegation=True
)


# Self-Healer Agent
self_healer = Agent(
    role='Certified Extraction Recovery and Correction Specialist',
    goal=(
        'Analyze the extraction output, precisely identify errors or missing fields, '
        'and perform careful, traceable corrective re-extraction using only evidence from the original document.'
    ),
    backstory=(
        "You are a specialist in error recovery for Commercial Property Insurance data extraction. "
        "You are trained as a Certified Data Recovery Analyst (CDRA) and a licensed Chartered Insurance Professional (CIP).\n\n"
        
        "Your job is to heal extraction outputs flagged by the Validator agent by:\n"
        "- Identifying incorrectly mapped fields, missing mandatory fields, type mismatches, formatting errors, and any property mis-separation\n"
        "- Performing highly targeted re-extraction attempts for only the fields that failed validation\n"
        "- Never hallucinating missing data: if information is genuinely missing in the document, leave the field empty ('')\n"
        "- Always sourcing corrections strictly from verifiable sections of the source document\n"
        "- Respecting the original mapping and instruction set used by the Value_Extractor agent\n"
        "- Maintaining strict separation of property-specific data (no contamination between properties)\n"
        "- Documenting your healing actions transparently: for each corrected field, specify (a) Issue detected, (b) Source text used for correction, (c) Reasoning behind the correction\n\n"
        
        "You prioritize data integrity above all. When healing, you also cross-reference nearby fields to catch hidden context "
        "(e.g., a missing 'Number of Stories' may be found in a different paragraph describing building features).\n\n"
        
        "If critical fields cannot be healed reliably, you escalate them clearly for manual review instead of guessing. "
        "You aim for traceable, auditable, compliance-ready corrected outputs."
    ),
    verbose=True,
    memory=memory,
    llm=llm,
    allow_delegation=True
)


# Output Assembler Agent
output_assembler = Agent(
    role='Certified Insurance Data Structuring Specialist',
    goal=(
        'Assemble the fully validated and corrected insurance extraction data into a precisely structured, '
        'property-wise and year-wise grouped JSON format, ensuring clean formatting and strict data integrity.'
    ),
    backstory=(
        "You are a senior data structuring specialist with expertise in preparing insurance data for downstream underwriting, "
        "actuarial modeling, and regulatory compliance.\n\n"
        
        "You operate with the following principles:\n"
        "- Never modify, reinterpret, or assume changes to any extracted value.\n"
        "- Group extracted data property-wise first, then year-wise where applicable (e.g., different years of values).\n"
        "- Maintain consistent field naming, casing, and data types throughout the JSON.\n"
        "- Eliminate any duplicate entries, empty placeholders, or structural noise.\n"
        "- Preserve full traceability between properties and their associated extracted fields.\n"
        "- Ensure that multi-year values (e.g., 'Building Value 2022' vs 'Building Value 2023') are cleanly separated but still associated to the correct property.\n\n"
        
        "You optimize the JSON output for:\n"
        "- Readability (logical grouping, minimal nesting)\n"
        "- System compatibility (parsable by underwriting, analytics, and policy issuance platforms)\n"
        "- Future auditing (easy to trace data lineage if needed)\n\n"
        "You are the final gatekeeper: your work must be meticulous, auditable, and ready for automated or manual consumption without further cleanup."
    ),
    verbose=True,
    memory=memory,
    llm=llm,
    allow_delegation=True
)


# Reporting Agent
reporting_agent = Agent(
    role='Certified Insurance Data Reporting and Compliance Officer',
    goal=(
        'Provide a comprehensive and insightful summary of the extraction process, highlighting success rates, '
        'missing fields, confidence levels, anomalies, and any insights relevant for senior management review. '
        'Ensure actionable information and data integrity concerns are clearly communicated.'
    ),
    backstory=(
        "You are a senior insurance data auditor with over 15 years of experience in auditing commercial insurance extractions. "
        "Your primary responsibility is to ensure that data extraction processes are transparent, accurate, and compliant with industry standards, "
        "while highlighting any potential concerns or areas for improvement.\n\n"

        "You specialize in reviewing large-scale data extractions and summarizing findings for senior management, "
        "ensuring they receive clear, actionable, and well-structured reports. Your reports are vital for the decision-making process, "
        "helping identify trends, data quality issues, and areas where further refinement is needed.\n\n"

        "Your reports contain:\n"
        "- **Extraction Success Rate**: Summarize the percentage of successful extractions versus failures.\n"
        "- **Missing Fields**: Highlight any missing fields, especially critical ones such as 'Property Name' or 'Total Insured Value'.\n"
        "- **Confidence Levels**: Report on the confidence of the extracted data (e.g., high, medium, low), giving transparency into the reliability of the outputs.\n"
        "- **Anomalies & Red Flags**: Include any outliers, inconsistencies, or unexpected entries that require senior management’s attention.\n"
        "- **Process Feedback**: Include recommendations for improving the extraction process based on identified bottlenecks or challenges.\n\n"

        "In your summaries, you will provide actionable insights, such as: 'Missing 15% of property names in the last batch', '95% confidence in extracted values', or 'The following properties had discrepancies between extracted and expected values'.\n\n"

        "Your goal is to make sure senior management is fully informed about the state of the extraction process, any gaps in the data, and the overall effectiveness of the value extraction system."
    ),
    verbose=True,
    memory=memory,
    llm=llm,
    allow_delegation=True
)


# Define Tasks
# Load Controlled Vocabulary
with open('controlled_vocabulary.json', 'r') as f:
    controlled_vocabulary = json.load(f)

# Folder containing the .txt files
folder_path = "Input"

# Read and combine all .txt files
document_texts = []
for filename in os.listdir(folder_path):
    if filename.endswith(".txt"):
        with open(os.path.join(folder_path, filename), 'r', encoding='utf-8') as f:
            content = f.read()
            document_texts.append(f"--- {filename} ---\n{content}\n")

# Combine into one string
combined_text = "\n".join(document_texts)

# Define the task
mappings_extractor_task = Task(
    name='Controlled Vocabulary-Based Field Mappings Extraction',
    agent=mappings_extractor,
    description=f"""
You are tasked with extracting standardized field mappings from insurance documents.

You must strictly match document fields using the Controlled Vocabulary provided below:

{json.dumps(controlled_vocabulary, indent=2)}

### Instructions:
- **Exact or synonym-based matches only**: Use the Controlled Vocabulary terms to find the correct mappings.
- **Avoid Assumptions**: If the meaning is unclear, mark it under 'ambiguous_fields' with a reason.
- **Handle Variations Smartly**: If document headers are slightly different but meaning is same (e.g., "Business Type" → "Occupation"), map it correctly.
- **Multi-Matches**: If a document field could belong to two categories, pick the **most precise match** and note ambiguity if necessary.
- **Case Sensitivity**: Matching is case-insensitive.
- **No Noise**: Do not extract any fields outside the Controlled Vocabulary.
- **Maintain Traceability**: For every mapping, maintain a comment explaining which document term you matched and why.

### Controlled Vocabulary Usage:
Each document field must map to one of the standardized fields or be marked ambiguous.

If a document field partially matches but is confusing, **prefer marking it ambiguous over wrong mapping**.

### Your Output MUST Be:
- Clean
- Precise
- No hallucination
- Scalable and auditable

Here is the input text:
{combined_text}
""",
    expected_output="""{
        "mappings": {
            "document_field_name": {
                "standard_field": "Controlled Vocabulary Field",
                "matched_by": "Exact Match / Synonym / Fuzzy Logic",
                "comment": "Explain why you matched it"
            },
        },
        "ambiguous_fields": {
            "document_field_name": "Reason for ambiguity"
        },
        "notes": "Any general observations or suggestions for Controlled Vocabulary improvements."
    }"""
)


insured_address_extractor_task = Task(
    name='Precise Extraction of Insured Property Addresses',
    agent=insured_address_extractor,
    description="""
You are tasked with extracting ONLY the addresses that belong to insured properties from insurance documents.

⚡ Critical Instructions:
- **Only extract addresses directly linked to insured properties.**
- **Explicitly ignore** mailing addresses, HQ addresses, broker addresses, loss payee addresses, or any non-insured addresses.
- Carefully differentiate between:
    - **Insured Site Address**, **Risk Location** → ✅ Must be extracted
    - **Mailing Address**, **HQ Address**, **Broker/Agent Address**, **Loss Payee Address** → ❌ Must NOT be extracted

📌 Extraction Rules:
- Prioritize fields containing keywords like:
    - "Insured Property Address", "Property Location", "Location Address", "Site Address", "Premises Address", "Address of Insured", "Storage Site", "Warehouse Location"
- Be highly skeptical if the section mentions:
    - "Mailing Address", "Correspondence Address", "Registered Office", "Broker Address", "Claims Contact", "Billing Address", etc.
- If unsure whether an address is insured or not, **DO NOT extract** and log it under "ambiguous_addresses" with reasons.

📜 Formatting Requirements:
- For each address extracted, include:
    - **Full extracted text**
    - **Source page or section (if available)**
    - **Confidence score** (High / Medium / Low)
- Normalize addresses by:
    - Removing unnecessary line breaks
    - Keeping commas properly
    - No artificial rephrasing; only clean what’s necessary

🔔 Edge Cases:
- If multiple addresses are grouped together (e.g., property schedule), split them property-wise if possible.
- If addresses are embedded in tables, handle table parsing carefully.

### Your Output MUST Be:
- Structured
- Trustworthy
- Audit-friendly

### Output Format Example:
{
    "insured_addresses": [
        {
            "address_text": "123 Industrial Road, Chicago, IL, 60605, USA",
            "source": "Page 5, Property Schedule",
            "confidence": "High"
        },
        {
            "address_text": "456 Warehouse Lane, Dallas, TX, 75212, USA",
            "source": "Page 7, Insured Sites Section",
            "confidence": "Medium"
        }
    ],
    "ambiguous_addresses": [
        {
            "address_text": "PO Box 789, Houston, TX, 77002",
            "reason": "Looks like a mailing address, not insured site."
        }
    ],
    "notes": "No non-insured addresses included."
}
""",
    expected_output="""{
        "insured_addresses": [
            {
                "address_text": "string",
                "source": "string",
                "confidence": "High/Medium/Low"
            }
        ],
        "ambiguous_addresses": [
            {
                "address_text": "string",
                "reason": "string"
            }
        ],
        "notes": "General comments on address extraction quality"
    }"""
)

value_extractor_task = Task(
    name='Precise Property-wise Insurance Data Extraction',
    agent=value_extractor,
    description="""
Your task is to extract **precise property-specific values** from complex insurance documents, focusing on the insured property’s data, coverage, and values. Ensure accuracy by following the **provided mappings**, handling dynamic instructions, and ensuring the correct extraction of each value based on the property.

### Extraction Instructions:
1. **Follow the Mappings Precisely**:
   - Use controlled vocabulary and predefined mappings like:
     - "Insured Name", "Property Name", "Occupation", "Business Type", "Number of Stories", "Currency", "PD Total", "BI Total", etc.
   - Make sure the extracted data corresponds exactly to the term (e.g., for **PD Total**, ensure it's the sum of Property Damage (PD) and Business Interruption (BI)).
   
2. **Property-Wise Extraction**:
   - Extract **distinct property records** ensuring that each property or building is kept separate. This means no cross-contamination between properties.
   - Maintain **auditable records** with clear references to source segments.

3. **Dynamic Adaptation to Instructions**:
   - If **scope limits** are provided (e.g., extracting only properties over a certain insured value), follow them strictly.
   - If **policy endorsements** are mentioned (e.g., flood zones, earthquake coverage), include them in your extraction when required.
   - Handle **exceptions** such as missing fields or variations in document structure (e.g., multi-page tables, unstructured text).
   
4. **Data Integrity**:
   - When in doubt, **flag data ambiguities** (e.g., mismatches between different values or unclear data), and escalate potential discrepancies.
   - Always **cite the exact source** for each value extracted (such as the section or page number) to maintain transparency.

### Key Extraction Areas:
- **Insurance Data**:
   - Coverage details (Property Damage, Business Interruption, etc.)
   - Currency and monetary amounts
   - Occupation/business type and property details
   - Number of Stories and any building-specific details

- **Ensure Formatting**:
   - Values should be in a **consistent format** (e.g., currency symbols, decimal places, units).
   - If the document contains complex tables, use specialized methods for **table parsing** to identify values.

### Example Output:
{
    "Insured Name": "<value or ''>",  
    "Properties": [  
        {  
            "Property Name": "<value or ''>",  
            "Occupation": "<value or ''>",  
            "Number of Stories": "<value or ''>",  
            "Address": "<address, Street Name, City, Country>",  
            "Coverage by Currencies": [  
                {  
                    "Currency": "USD",  
                    "PD + BI Total (100%)": <numeric value>,  
                    "PD Total": <numeric value>,  
                    "PD (Building)": <numeric value>,  
                    "PD (Machinery & Equipment)": <numeric value>,  
                    "PD (Contents)": <numeric value>,  
                    "PD (Stock & Inventory)": <numeric value>,  
                    "PD (Others)": <numeric value>,  
                    "Business Interruption": <numeric value>,  
                    "Other BI Values": <numeric value>  
                },  
                {  
                    "Currency": "INR",  
                    "PD + BI Total (100%)": <numeric value>,  
                    "PD Total": <numeric value>,  
                    "PD (Building)": <numeric value>,  
                    "PD (Machinery & Equipment)": <numeric value>,  
                    "PD (Contents)": <numeric value>,  
                    "PD (Stock & Inventory)": <numeric value>,  
                    "PD (Others)": <numeric value>,  
                    "Business Interruption": <numeric value>,  
                    "Other BI Values": <numeric value>  
                }  
            ]  
        },  
        {  
            "Property Name": "<value or ''>",  
            "Occupation": "<value or ''>",  
            "Number of Stories": "<value or ''>",  
            "Address": "<address, Street Name, City, Country>",  
            "Coverage by Currencies": [  
                {  
                    "Currency": "USD",  
                    "PD + BI Total (100%)": <numeric value>,  
                    "PD Total": <numeric value>,  
                    "PD (Building)": <numeric value>,  
                    "PD (Machinery & Equipment)": <numeric value>,  
                    "PD (Contents)": <numeric value>,  
                    "PD (Stock & Inventory)": <numeric value>,  
                    "PD (Others)": <numeric value>,  
                    "Business Interruption": <numeric value>,  
                    "Other BI Values": <numeric value>  
                },  
                {  
                    "Currency": "JPY",  
                    "PD + BI Total (100%)": <numeric value>,  
                    "PD Total": <numeric value>,  
                    "PD (Building)": <numeric value>,  
                    "PD (Machinery & Equipment)": <numeric value>,  
                    "PD (Contents)": <numeric value>,  
                    "PD (Stock & Inventory)": <numeric value>,  
                    "PD (Others)": <numeric value>,  
                    "Business Interruption": <numeric value>,  
                    "Other BI Values": <numeric value>  
                }  
            ]  
        }  
    ],  
    "Expired Properties": [  
        {  
            "Property Name": "<value or ''>",  
            "Occupation": "<value or ''>",  
            "Number of Stories": "<value or ''>",  
            "Address": "<address, Street Name, City, Country>",  
            "Coverage by Currencies": [  
                {  
                    "Currency": "USD",  
                    "PD + BI Total (100%)": <numeric value>,  
                    "PD Total": <numeric value>,  
                    "PD (Building)": <numeric value>,  
                    "PD (Machinery & Equipment)": <numeric value>,  
                    "PD (Contents)": <numeric value>,  
                    "PD (Stock & Inventory)": <numeric value>,  
                    "PD (Others)": <numeric value>,  
                    "Business Interruption": <numeric value>,  
                    "Other BI Values": <numeric value>  
                },  
                {  
                    "Currency": "INR",  
                    "PD + BI Total (100%)": <numeric value>,  
                    "PD Total": <numeric value>,  
                    "PD (Building)": <numeric value>,  
                    "PD (Machinery & Equipment)": <numeric value>,  
                    "PD (Contents)": <numeric value>,  
                    "PD (Stock & Inventory)": <numeric value>,  
                    "PD (Others)": <numeric value>,  
                    "Business Interruption": <numeric value>,  
                    "Other BI Values": <numeric value>  
                }  
            ]  
        }  
    ]  
}
""",
    expected_output="""{
        "Insured Name": "string",  
        "Properties": [  
            {  
                "Property Name": "string",  
                "Occupation": "string",  
                "Number of Stories": "string",  
                "Address": "string",  
                "Coverage by Currencies": [  
                    {  
                        "Currency": "string",  
                        "PD + BI Total (100%)": "numeric",  
                        "PD Total": "numeric",  
                        "PD (Building)": "numeric",  
                        "PD (Machinery & Equipment)": "numeric",  
                        "PD (Contents)": "numeric",  
                        "PD (Stock & Inventory)": "numeric",  
                        "PD (Others)": "numeric",  
                        "Business Interruption": "numeric",  
                        "Other BI Values": "numeric"  
                    }  
                ]  
            }  
        ],  
        "Expired Properties": [  
            {  
                "Property Name": "string",  
                "Occupation": "string",  
                "Number of Stories": "string",  
                "Address": "string",  
                "Coverage by Currencies": [  
                    {  
                        "Currency": "string",  
                        "PD + BI Total (100%)": "numeric",  
                        "PD Total": "numeric",  
                        "PD (Building)": "numeric",  
                        "PD (Machinery & Equipment)": "numeric",  
                        "PD (Contents)": "numeric",  
                        "PD (Stock & Inventory)": "numeric",  
                        "PD (Others)": "numeric",  
                        "Business Interruption": "numeric",  
                        "Other BI Values": "numeric"  
                    }  
                ]  
            }  
        ]  
    }"""
)

validation_task = Task(
    name='Enhanced Validation of Extracted Data (With String Similarity)',
    description=(
        "Perform a strict validation of extracted insurance document data, covering both numeric and string fields.\n\n"
        "🔎 Validation Scope:\n"
        "- Numeric fields (coverage amounts, premiums, limits).\n"
        "- String fields (insured names, street addresses, city, state, zip code, policy numbers).\n\n"
        "🛠 Validation Steps:\n"
        "1. For each extracted field:\n"
        "   - Locate corresponding field in the source document.\n"
        "   - Normalize values:\n"
        "     - For numerics: Remove commas, dollar signs, spaces.\n"
        "     - For strings: Trim whitespace, ignore case unless case-sensitive match is required.\n"
        "2. Compare extracted value against source value.\n"
        "3. If mismatch on string fields:\n"
        "   - Calculate string similarity (e.g., Levenshtein Distance or fuzzy matching).\n"
        "   - If similarity score ≥ 90%, flag as 'minor typo'.\n"
        "   - If similarity score < 90%, flag as 'critical mismatch'.\n\n"
        "✅ Mark fields as:\n"
        "- 'validated' if match.\n"
        "- 'minor_typo' if slight mismatch (likely recoverable).\n"
        "- 'critical_mismatch' if major discrepancy.\n"
        "- 'missing' if field is absent.\n\n"
        "⚡ Important:\n"
        "- Addresses must match completely: street number, name, unit/suite (if any).\n"
        "- Policy Numbers must match exactly (no typos allowed).\n"
        "- Currency values must match after normalization.\n\n"
        "✅ Output JSON:\n"
        "{\n"
        "  'validated_fields': [...],\n"
        "  'minor_typo_fields': [...],\n"
        "  'critical_mismatches': [...],\n"
        "  'missing_fields': [...],\n"
        "  'notes': 'General observations'\n"
        "}\n\n"
        "🚑 Send 'minor_typo_fields' and 'critical_mismatches' to self-healer for reprocessing."
    ),
    expected_output=(
        "Structured JSON report including validated, minor typos, critical mismatches, missing fields, and detailed notes."
    ),
    agent=validator,
    output_to=self_healer,
    async_execution=True
)

self_heal_task = Task(
    name='Self Healing of Validation Failures',
    description=(
        "Perform self-healing of data validation issues identified during extraction validation.\n\n"
        "🚑 Healing Scope:\n"
        "1. For 'minor_typo_fields' (similarity ≥ 90%):\n"
        "   - Accept and auto-correct the extracted field to match the source value exactly.\n"
        "   - Note the correction.\n\n"
        "2. For 'critical_mismatches' (similarity < 90% or major differences):\n"
        "   - Apply aggressive text cleanup and normalization (e.g., fixing spacing issues, reading faint text).\n"
        "   - Compare re-extracted value again to the original source.\n"
        "   - If still mismatched after retry, flag for manual review.\n\n"
        "🧠 Important Considerations:\n"
        "- Never silently drop or guess values.\n"
        "- Log all corrections and retries transparently.\n"
        "- Prioritize preserving original document semantics.\n\n"
        "✅ Output JSON:\n"
        "{\n"
        "  'healed_fields': [...],\n"
        "  're_extracted_fields': [...],\n"
        "  'manual_review_required': [...],\n"
        "  'healing_notes': 'Summary of healing actions taken.'\n"
        "}\n\n"
        "📣 Return the healed fields for final assembly."
    ),
    expected_output=(
        "Structured JSON report listing healed fields, fields needing manual review, "
        "and any additional notes about the healing process."
    ),
    agent=self_healer,
    output_to=output_assembler,
    async_execution=True
)

assemble_task = Task(
    name='Assemble Final Structured Output JSON',
    description=(
        "🛠️ Assemble the final cleaned and validated data into the specified JSON format.\n\n"
        "✅ JSON Output Structure:\n"
        "{\n"
        "  'Insured Name': '<value or empty string>',\n"
        "  'Properties': [\n"
        "    {\n"
        "      'Property Name': '<value or empty string>',\n"
        "      'Occupation': '<value or empty string>',\n"
        "      'Number of Stories': '<value or empty string>',\n"
        "      'Address': '<Street, City, Country>',\n"
        "      'Coverage by Currencies': [\n"
        "        {\n"
        "          'Currency': '<Currency>',\n"
        "          'PD + BI Total (100%)': <numeric value>,\n"
        "          'PD Total': <numeric value>,\n"
        "          'PD (Building)': <numeric value>,\n"
        "          'PD (Machinery & Equipment)': <numeric value>,\n"
        "          'PD (Contents)': <numeric value>,\n"
        "          'PD (Stock & Inventory)': <numeric value>,\n"
        "          'PD (Others)': <numeric value>,\n"
        "          'Business Interruption': <numeric value>,\n"
        "          'Other BI Values': <numeric value>\n"
        "        },\n"
        "        ...\n"
        "      ]\n"
        "    },\n"
        "    ...\n"
        "  ],\n"
        "  'Expired Properties': [...],\n"
        "  'Notes': [\n"
        "    'Field <field_name> for <Property Name> flagged for manual review.',\n"
        "    'Currency mismatch for Property <Property Name>.'\n"
        "  ]\n"
        "}\n\n"
        "🧹 Formatting and Data Filling Rules:\n"
        "- All string fields must be populated. If missing, set as an empty string ''.\n"
        "- All numeric fields must be populated. If missing, set as 0.0.\n"
        "- Always output 'Coverage by Currencies' as a non-empty array (even if one currency).\n"
        "- If a field was flagged during validation/self-healing and couldn't be confidently healed, record it in the 'Notes' section.\n"
        "- 'Notes' should clearly state what field/property needs manual review.\n"
        "- Maintain clean formatting and valid JSON structure.\n"
    ),
    expected_output=(
        "A structured JSON object combining validated, healed data along with a 'Notes' array "
        "listing any fields that require manual review."
    ),
    agent=output_assembler,
    output_to=reporting_agent,  # optionally send it for post-run reporting
    async_execution=False
)

report_task = Task(
    name="Post-Run Extraction Report",
    description=(
        "Generate a comprehensive post-run extraction report that highlights key findings, "
        "issues encountered during data extraction, and any flagged fields requiring manual review. "
        "The report should include summaries of successful extractions, mismatches, ambiguities, and validation issues, "
        "along with recommendations for improvement."
    ),
    agent=reporting_agent,
    expected_output="""{
        "summary": {
            "total_extracted_fields": "int",
            "successful_extractions": "int",
            "failed_extractions": "int",
            "manual_review_needed": "int"
        },
        "detailed_report": {
            "field_name": {
                "status": "string",  # 'success', 'failed', 'manual_review'
                "issues_found": "string",
                "suggestions": "string"
            }
        },
        "notes": "Any general observations, challenges faced, or potential improvements for the extraction process."
    }"""
)

# Define the Crew workflow
crew = Crew(
    agents=[
        mappings_extractor,
        insured_address_extractor,
        value_extractor,
        validator,
        self_healer,
        output_assembler,
        reporting_agent
    ],
    tasks=[
        mappings_extractor_task,
        insured_address_extractor_task,
        value_extractor_task,
        validation_task,
        self_heal_task,
        assemble_task,
        report_task
    ],
    verbose=True,
    process=Process.sequential,
    manager_llm=llm
)

# Kick off the workflow
result = crew.kickoff()

print(result)

# # Expose the crew
# def run_insurance_extraction(user_input):
#     return crew.kickoff(inputs={"input": user_input})

#Commented Old Code
# Value_extractor = Agent(
#     role='Certified Property Insurance Value Extraction Analyst',
#     goal='Extract precise, property-wise insurance data values from source documents, adhering strictly to the provided mappings and dynamic extraction instructions.',
#     backstory=(
#         "You are an elite insurance data extraction specialist with over 10 years of intensive experience in Commercial Property Insurance. "
#         "You are CPCU (Chartered Property Casualty Underwriter) certified, a member of the Society of Insurance Research (SIR), and recognized by the Association of Insurance Data Analysts (AIDA) for excellence in underwriting data accuracy. "
#         "\n\n"
#         "Your core competency lies in methodically parsing complex insurance documents such as Statement of Values (SOVs), property schedules, appraisals, inspection reports, and underwriting submissions, and extracting granular data in a property-specific manner. "
#         "\n\n"
#         "You operate using either predefined mappings supplied by underwriting teams or updated mappings generated by the specialized Mapping Extractor agent. "
#         "You deeply understand that 'property-wise extraction' means maintaining distinct records for each building or property listed, ensuring no cross-contamination of data. "
#         "\n\n"
#         "In addition to mappings, you are capable of dynamically adapting to supplementary instructions, including but not limited to: "
#         "- Specific formatting requirements (e.g., currency formatting, decimal places). "
#         "- Extraction scope limits (e.g., only properties over a certain insured value). "
#         "- Policy-specific endorsements (e.g., flood zones, earthquake coverage). "
#         "- Document structure variations (e.g., multi-page tables, narrative-style inputs). "
#         "- Exception handling (e.g., missing data fields, alternative data locations). "
#         "\n\n"
#         "You are vigilant about data integrity, tagging uncertainties when encountered, and escalating potential discrepancies or ambiguous mappings. "
#         "You always cite the exact source text segment when extracting each value for traceability and audit compliance. "
#         "\n\n"
#         "Your extraction outputs are structured, transparent, auditable, and optimized for downstream underwriting and actuarial processing workflows. "
#         "You do not make assumptions; you operate based solely on observable evidence from the document and the instructions provided."
#     ),
#     verbose=True,
#     memory=memory,
#     llm=llm,
#     allow_delegation=True
# )

# Mappings_extractor = Agent(
#     role='Certified Commercial Insurance Data Mapping Specialist',
#     goal='Accurately identify and map property insurance data fields from complex documents, ensuring compliance with defined mappings, terminologies, and industry standards.',
#     backstory=(
#         "You are a highly credentialed insurance data analyst with over 12 years of deep specialization in Commercial Property Insurance. "
#         "You hold CPCU (Chartered Property Casualty Underwriter) and AINS (Associate in General Insurance) certifications, accredited by The Institutes. "
#         "You are also recognized by the Association of Insurance Data Analysts (AIDA) and have served on the Data Standards Committee for the Commercial Insurance Board (CIB) for three consecutive years. "
#         "\n\n"
#         "Throughout your career, you have worked with top-tier insurers like AIG, Chubb, and Zurich, meticulously designing and auditing data extraction pipelines that are fully compliant with regulatory frameworks like NAIC (National Association of Insurance Commissioners) guidelines. "
#         "\n\n"
#         "Your primary responsibility now is to ingest structured field definitions—consisting of field names, descriptions, and synonymous terms—from a provided input. "
#         "You are tasked with reading diverse and often complex source documents, including but not limited to property schedules, valuation reports, Statement of Values (SOVs), underwriting submissions, and broker narratives. "
#         "\n\n"
#         "Your expertise lies in interpreting the semantic context and locating potential mappings accurately. You prioritize precision over speed and have a zero-tolerance policy for hallucination or assumption without evidence from the source text. "
#         "\n\n"
#         "Once mappings are confidently identified, you prepare a structured output detailing the matched field, source reference, and any relevant mapping context, and pass this clean, semantically grounded output to the next downstream agent responsible for final extraction. "
#         "You are empowered to flag ambiguities, missing fields, or inconsistencies early for escalation. "
#         "\n\n"
#         "Your analytical judgment is trusted industry-wide. Accuracy, compliance, and a forensic approach to semantic meaning are your defining traits."
#     ),
#     verbose=True,
#     memory=memory,
#     llm=llm,
#     allow_delegation=True
# )

# validator = Agent(
#     role='Extraction Validator',
#     goal='Ensure all extracted data is accurate, strictly mapped, numeric fields are numbers, and no missing critical fields.',
#     backstory='You are a senior quality analyst, specialized in validating property insurance extractions for strict audit processes.',
#     verbose=True,
#     memory=memory,
#     llm=llm,
#     allow_delegation=True
# )

# self_healer = Agent(
#     role='Extraction Self-Healer',
#     goal='Identify mistakes/missing fields in the extraction and attempt corrective re-extraction without hallucinating.',
#     backstory='You are an expert error recovery bot trained to correct and heal broken data extractions specifically in property insurance.',
#     verbose=True,
#     memory=memory,
#     llm=llm,
#     allow_delegation=True
# )

# output_assembler = Agent(
#     role='Final Output Assembler',
#     goal='Assemble the extracted and validated insurance data into the correct JSON format grouped property-wise and year-wise.',
#     backstory='You specialize in compiling clean structured JSONs for insurance records without introducing any noise.',
#     verbose=True,
#     memory=memory,
#     llm=llm,
#     allow_delegation=True
# )


# reporting_agent = Agent(
#     role='Extraction Reporting Officer',
#     goal='Summarize the extraction results, missing fields, confidence levels, and any observed anomalies.',
#     backstory='You are a professional insurance data auditor. Your job is to provide clean reports for senior management review.',
#     verbose=True,
#     memory=memory,
#     llm=llm,
#     allow_delegation=True
# )

# mappings_extractor_task = Task(
#     name='Extract Field Mappings',
#     description=(
#         "Analyze the provided insurance document (e.g., SOV, property schedule, underwriting submission) "
#         "and extract a clear field-to-field mapping structure.\n\n"
#         "Steps:\n"
#         "- Identify all relevant columns, labels, or fields (e.g., 'TIV', 'Replacement Cost', 'Building Value', 'Business Interruption').\n"
#         "- Map each identified label to a **standardized insurance field**.\n"
#         "- Standard fields may include: Building Value, Contents Value, Business Interruption Value, Year Built, Construction Type, Protection, Occupancy, Flood Zone, Earthquake Zone, Address, Zip Code, County, and any others relevant.\n"
#         "- If multiple versions of the same field exist (e.g., multiple types of 'Value'), note them clearly.\n"
#         "- If no mappings are explicitly visible, infer mappings based only on strong cues — DO NOT assume if highly uncertain; instead, flag them as 'Needs Clarification'.\n"
#         "- Output should be a JSON dictionary mapping Document Fields -> Standardized Fields.\n"
#         "- Maintain high traceability; for each field mapped, if possible, cite the document section or heading where it appeared."
#     ),
#     expected_output={
#         "mappings": {
#             "document_field_name": "standard_field_name",
#             "document_field_name2": "standard_field_name2",
#             # Example
#             "TIV (Total Insured Value)": "Total Insured Value",
#             "Bldg RC": "Replacement Cost - Building",
#         },
#         "notes": "List any ambiguous fields or mapping uncertainties here."
#     }
# )

# value_extractor_task = Task(
#     name='Precise Property-wise Insurance Data Extraction',
#     description="""
# Your task is to extract **precise property-specific values** from complex insurance documents, focusing on the insured property’s data, coverage, and values. Ensure accuracy by following the **provided mappings**, handling dynamic instructions, and ensuring the correct extraction of each value based on the property.

# ### Extraction Instructions:
# 1. **Follow the Mappings Precisely**:
#    - Use controlled vocabulary and predefined mappings like:
#      - "Insured Name", "Property Name", "Occupancy", "Business Type", "Number of Stories", "Currency", "PD Total", "BI Total", etc.
#    - Make sure the extracted data corresponds exactly to the term (e.g., for **PD Total**, ensure it's the sum of Property Damage (PD) and Business Interruption (BI)).
   
# 2. **Property-Wise Extraction**:
#    - Extract **distinct property records** ensuring that each property or building is kept separate. This means no cross-contamination between properties.
#    - Maintain **auditable records** with clear references to source segments.

# 3. **Dynamic Adaptation to Instructions**:
#    - If **scope limits** are provided (e.g., extracting only properties over a certain insured value), follow them strictly.
#    - If **policy endorsements** are mentioned (e.g., flood zones, earthquake coverage), include them in your extraction when required.
#    - Handle **exceptions** such as missing fields or variations in document structure (e.g., multi-page tables, unstructured text).
   
# 4. **Data Integrity**:
#    - When in doubt, **flag data ambiguities** (e.g., mismatches between different values or unclear data), and escalate potential discrepancies.
#    - Always **cite the exact source** for each value extracted (such as the section or page number) to maintain transparency.

# ### Key Extraction Areas:
# - **Insurance Data**:
#    - Coverage details (Property Damage, Business Interruption, etc.)
#    - Currency and monetary amounts
#    - Occupation/business type and property details
#    - Number of Stories and any building-specific details

# - **Ensure Formatting**:
#    - Values should be in a **consistent format** (e.g., currency symbols, decimal places, units).
#    - If the document contains complex tables, use specialized methods for **table parsing** to identify values.

# ### Example Output:
# {
#     "properties": [
#         {
#             "property_name": "Building A",
#             "insured_name": "ABC Corporation",
#             "coverage": {
#                 "PD_BI_Total": "2,500,000 USD",
#                 "PD_Building": "1,000,000 USD",
#                 "PD_Machinery": "500,000 USD",
#                 "PD_Contents": "300,000 USD",
#                 "PD_Stock": "200,000 USD",
#                 "PD_Others": "500,000 USD",
#                 "BI_Total": "400,000 USD"
#             },
#             "currency": "USD",
#             "occupation": "Manufacturing",
#             "number_of_stories": "5",
#             "notes": "Flood coverage included",
#             "source": "Page 12, Property Schedule"
#         },
#         {
#             "property_name": "Building B",
#             "insured_name": "XYZ Inc.",
#             "coverage": {
#                 "PD_BI_Total": "3,000,000 EUR",
#                 "PD_Building": "1,500,000 EUR",
#                 "PD_Machinery": "800,000 EUR",
#                 "PD_Contents": "600,000 EUR",
#                 "PD_Stock": "100,000 EUR",
#                 "PD_Others": "500,000 EUR",
#                 "BI_Total": "500,000 EUR"
#             },
#             "currency": "EUR",
#             "occupation": "Warehousing",
#             "number_of_stories": "3",
#             "notes": "No additional endorsements",
#             "source": "Page 15, Insured Property Details"
#         }
#     ],
#     "errors": [
#         {
#             "error_type": "Missing Data",
#             "message": "Missing value for BI Total in Building C",
#             "source": "Page 19, Property Schedule"
#         }
#     ],
#     "notes": "All properties extracted successfully, but some missing values require further verification."
# }
# """,
#     expected_output={
#         "properties": [
#             {
#                 "property_name": "string",
#                 "insured_name": "string",
#                 "coverage": {
#                     "PD_BI_Total": "string",
#                     "PD_Building": "string",
#                     "PD_Machinery": "string",
#                     "PD_Contents": "string",
#                     "PD_Stock": "string",
#                     "PD_Others": "string",
#                     "BI_Total": "string"
#                 },
#                 "currency": "string",
#                 "occupation": "string",
#                 "number_of_stories": "string",
#                 "notes": "string",
#                 "source": "string"
#             }
#         ],
#         "errors": [
#             {
#                 "error_type": "string",
#                 "message": "string",
#                 "source": "string"
#             }
#         ],
#         "notes": "General comments on extraction accuracy"
#     }
# )

# validation_task = Task(
#     description='Validate extracted data for correctness, field matching, types, and missing information.',
#     agent=validator
# )

# self_heal_task = Task(
#     description='If validation fails, attempt re-extraction and healing of missing fields.',
#     agent=self_healer
# )

# self_heal_task = Task(
#     name='Self Healing of Validation Failures',
#     description=(
#         "Perform self-healing of data validation issues identified during extraction validation.\n\n"
#         "🚑 Healing Scope:\n"
#         "1. For 'minor_typo_fields' (similarity ≥ 90%):\n"
#         "   - Accept and auto-correct the extracted field to match the source value exactly.\n"
#         "   - Note the correction.\n\n"
#         "2. For 'critical_mismatches' (similarity < 90% or major differences):\n"
#         "   - Re-run localized OCR or re-extraction strategies on the affected field areas.\n"
#         "   - Apply aggressive text cleanup and normalization (e.g., fixing spacing issues, reading faint text).\n"
#         "   - Compare re-extracted value again to the original source.\n"
#         "   - If still mismatched after retry, flag for manual review.\n\n"
#         "🧠 Important Considerations:\n"
#         "- Never silently drop or guess values.\n"
#         "- Log all corrections and retries transparently.\n"
#         "- Prioritize preserving original document semantics.\n\n"
#         "✅ Output JSON:\n"
#         "{\n"
#         "  'healed_fields': [...],\n"
#         "  're_extracted_fields': [...],\n"
#         "  'manual_review_required': [...],\n"
#         "  'healing_notes': 'Summary of healing actions taken.'\n"
#         "}\n\n"
#         "📣 Return the healed fields for final assembly."
#     ),
#     expected_output=(
#         "Structured JSON report listing healed fields, fields needing manual review, "
#         "and any additional notes about the healing process."
#     ),
#     agent=self_healer,
#     output_to=output_assembler,
#     async_execution=True
# )

# assemble_task = Task(
#     description='Assemble the final output JSON cleanly.',
#     agent=output_assembler
# )

# report_task = Task(
#     description='Generate a post-run extraction report highlighting key findings and issues.',
#     agent=reporting_agent
# )