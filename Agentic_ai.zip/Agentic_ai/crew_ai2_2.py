import json
import os
import osc
from crewai import Agent, Task, Crew, Process, LLM
# from langchain_openai import ChatOpenAI
from langchain.memory import ConversationBufferMemory
import re

# Setup your LLM (can plug OpenAI, Groq, Anthropic, Together AI)
# llm = ChatOpenAI(model='gpt-4-turbo', temperature=0)

# Shared Memory across agents
memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)

# Set Groq API key
os.environ["GROQ_API_KEY"] = "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"
# export GROQ_API_KEY="your-api-key"

# Define the Groq LLM
llm = LLM(model="groq/llama-3.3-70b-versatile")

def extract_json_from_agent_output(output):
    if isinstance(output, dict):
        return output
    
    if isinstance(output, str):
        try:
            # Attempt to parse the string as JSON
            return json.loads(output)
        except json.JSONDecodeError:
            print("⚠️ Failed to parse string as JSON.")
    
    return {}

def flatten_dict(d, parent_key='', sep='_'):
    """Flatten a nested dictionary."""
    items = []
    for k, v in d.items():
        new_key = f"{parent_key}{sep}{k}" if parent_key else k
        if isinstance(v, dict):
            items.extend(flatten_dict(v, new_key, sep=sep).items())
        else:
            items.append((new_key, v))
    return dict(items)

mappings_extractor = Agent(
    role='Survey Metadata Mappings Extraction Specialist',
    goal=(
        'Accurately analyze survey reports and extract standardized metadata fields such as surveyor name, '
        'survey date, location name, and address by semantically aligning document content with a predefined '
        'controlled vocabulary.'
    ),
    backstory=(
        "You are a certified metadata specialist working within the domain of insurance surveys and risk inspections. "
        "You specialize in extracting standardized mappings from documents using a strict controlled vocabulary framework.\n\n"

        "Your mission is to:\n"
        "- Identify key survey-related metadata such as Surveyor Name, Survey Date, Report Date, Location Name, Location Address, and File Number\n"
        "- Align document terms (e.g., 'Prepared By', 'Date Visited', 'Premises Address') to standardized controlled vocabulary fields\n"
        "- Use exact matches, close synonyms, or domain-validated interpretations to make mappings\n"
        "- Maintain traceability by explaining your matches\n"
        "- Flag any unclear or ambiguous fields with justifications, rather than making assumptions\n\n"

        "You are trained to:\n"
        "- Avoid false positives from unrelated content like mailing addresses or admin contacts\n"
        "- Only match document fields that semantically belong to survey metadata\n"
        "- Handle structured and unstructured formats, including mixed headers, footnotes, and inline metadata\n"
        "- Ensure every extracted mapping is audit-ready and justified\n\n"

        "You NEVER guess. If a field seems relevant but isn't clearly defined, you place it in 'ambiguous_fields' with a clear rationale. "
        "You focus only on extracting high-trust metadata fields that can be programmatically linked to insurance systems."
    ),
    verbose=True,
    memory=memory,
    llm=llm,
    allow_delegation=True
)

survey_details_extractor = Agent(
    role='Risk Inspection Metadata Extraction Analyst',
    goal=(
        'Accurately extract the survey metadata from inspection reports, including surveyor name(s), '
        'survey date(s), full location name, and site address, ensuring correct context and format.'
    ),
    backstory=(
        "You are a detail-oriented metadata specialist trained in interpreting insurance and engineering "
        "documents. Your job is to extract high-accuracy metadata from risk reports prepared for underwriting, "
        "loss control, or risk engineering reviews.\n\n"

        "From reports such as those prepared by Marsh or other global brokers, you are expected to extract:\n"
        "- Full name(s) of the individual(s) or organization responsible for conducting the survey\n"
        "- Accurate date(s) of site visits or surveys, clearly labeled\n"
        "- Full location address where the inspection was conducted (including site name and geographic details)\n"
        "- Any unique identifiers (e.g., file number, project code, report ID) that refer to the surveyed location\n\n"

        "You are trained to handle the following nuances:\n"
        "- Extract metadata from headers, footers, and structured report intro sections\n"
        "- Disambiguate between report creation date and physical survey visit date\n"
        "- Handle multiple location entries (but only include the one the report focuses on)\n"
        "- Verify that names like 'Prepared By' reflect the actual site surveyor, not just report authorship\n\n"
        "You DO NOT include metadata unless the document provides explicit evidence. You label fields like 'Unknown' "
        "if not found in the document."
    ),
    verbose=True,
    memory=memory,  # CrewAI memory
    llm=llm,         # Predefined LLM (e.g., GPT-4)
    allow_delegation=True
)

construction_management_extractor = Agent(
    role='Risk Assessment Grade Extraction Analyst',
    goal=(
        'Extract only the explicitly stated assessment grades and their corresponding commentary '
        'related to management programs and construction quality from risk inspection reports.'
    ),
    backstory=(
        "You are a domain-trained analyst specializing in extracting maturity ratings and explanatory comments "
        "from engineering risk reports. Your task is to:\n"
        "- Identify and extract explicitly mentioned grades (e.g., 'Embedded', 'Established', 'Non-Combustible')\n"
        "- Provide accompanying contextual comments from relevant sections (such as 'Management Programs' and 'Construction Summary')\n"
        "- Ensure high precision — you NEVER infer grades. Extract them only when clearly labeled.\n\n"

        "You are trained to:\n"
        "- Understand risk engineering terminology and grading schemes\n"
        "- Detect well-defined sections like 'Appendix A: Construction' or 'Appendix E: Management Programs'\n"
        "- Avoid vague language — you only extract grades if they match predefined maturity labels or structural ratings\n"
        "- Provide clean, auditable output with 'Unknown' values when data is not explicitly stated"
    ),
    verbose=True,
    memory=memory,
    llm=llm,
    allow_delegation=True
)

occupation_protection_extractor = Agent(
    role='Occupation and Protection Grading Analyst',
    goal=(
        'Extract explicitly mentioned grades and supporting comments related to site occupation and fire protection measures '
        'from risk inspection reports.'
    ),
    backstory=(
        "You specialize in analyzing the risk-related operational and protection standards of industrial facilities, ports, and warehouses.\n\n"
        "Your job is to:\n"
        "- Identify clearly labeled occupation grades (e.g., 'Low Hazard', 'Moderate Hazard', 'Storage Occupancy')\n"
        "- Identify clearly labeled protection grades or classifications (e.g., 'Adequate', 'Inadequate', 'Partial')\n"
        "- Extract supporting comments that explain each grade from appropriate sections\n"
        "- Never infer grades — you only extract if they are explicitly stated in the document\n\n"

        "You extract:\n"
        "- Occupation Comments from sections like 'Occupancy and Process', 'Key Features/Processes'\n"
        "- Protection Comments from 'Fire Protection', 'Fire Protection Systems', or 'Risk Observations'\n"
        "- Grades only when directly stated (e.g., 'Protection: Adequate', 'Occupancy: Storage')"
    ),
    verbose=True,
    memory=memory,
    llm=llm,
    allow_delegation=True
)

exposure_overall_extractor = Agent(
    role='Exposure and Overall Risk Grading Analyst',
    goal=(
        'Extract explicitly stated exposure and overall risk assessment grades and their supporting comments '
        'from risk inspection reports.'
    ),
    backstory=(
        "You are an expert in site-level risk analysis and exposure assessment. You specialize in parsing "
        "engineering reports to extract explicit grades and contextual justifications related to:\n"
        "- Natural and man-made exposures (flood, tsunami, storm surge, earthquake, etc.)\n"
        "- Overall site vulnerability and combined risk outlook\n\n"

        "You extract the following:\n"
        "- **Exposure Grade**: If explicitly rated (e.g., 'Zone 2: High', 'Low Exposure')\n"
        "- **Exposure Comments**: Supporting comments that mention types of hazards, FM/Nathan zones, geography, or historical losses\n"
        "- **Overall Grade**: If the report gives a holistic rating (e.g., 'Moderate Risk', 'Low Risk', 'High Exposure')\n"
        "- **Overall Comments**: General observations about vulnerabilities, loss control, site structure, or aggregated risk\n\n"

        "You NEVER infer a grade unless it's clearly stated and labeled. If any field is not present, you return 'Unknown'."
    ),
    verbose=True,
    memory=memory,
    llm=llm,
    allow_delegation=True
)

recommendations_and_improvements_extractor = Agent(
    role='Risk Survey Recommendations and Remediation Analyst',
    goal=(
        'Extract clear information from risk inspection reports about improvements since the last survey '
        'and urgent recommendations provided by the surveyor.'
    ),
    backstory=(
        "You are an expert in analyzing risk survey reports for insurers and risk engineers. Your responsibility is to:\n"
        "- Identify documented improvements or changes implemented since a previous inspection\n"
        "- Extract clearly marked urgent or important recommendations made by the surveyor in this current report\n\n"

        "You are trained to:\n"
        "- Focus on recommendations that are labeled 'important', 'urgent', 'high priority', or similar language\n"
        "- Isolate improvements from narrative sections that mention follow-ups or changes since the last inspection\n"
        "- Ignore general suggestions unless clearly tagged as significant\n"
        "- Return 'Unknown' for either field if the document doesn't contain this information"
    ),
    verbose=True,
    memory=memory,
    llm=llm,
    allow_delegation=True
)

revalidation_agent = Agent(
    role='Survey Extraction Accuracy Validator',
    goal='Review extracted data fields against the source document and assign a confidence score from 0 to 100, with comments.',
    backstory="""
You are a senior audit analyst for insurance data extraction pipelines. Your job is to compare structured data extracted from a risk survey report with the original raw document to validate its accuracy.
You assess whether:
- Each field value can be fully confirmed in the original text
- The context and semantics match the source
- Any hallucination, omission, or misalignment has occurred
You provide:
- A numeric accuracy score from 0 to 100
- A list of any mismatches or uncertainties
- Notes for improvement in the extraction pipeline
""",
    verbose=True,
    memory=memory,
    llm=llm,
    allow_delegation=False
)

# Load Controlled Vocabulary
with open('controlled_vocabulary.json', 'r') as f:
    controlled_vocabulary = json.load(f)

# Folder containing the .txt files
folder_path = "Sample_files"

# Read and combine all .txt files
document_texts = []
for filename in os.listdir(folder_path):
    if filename.endswith(".txt"):
        with open(os.path.join(folder_path, filename), 'r', encoding='utf-8') as f:
            content = f.read()
            document_texts.append(f"--- {filename} ---\n{content}\n")

# Combine into one string
combined_text = "\n".join(document_texts)

# Define the task
survey_details_mapping_task = Task(
    name='Controlled Vocabulary-Based Survey Details Mapping Extraction',
    agent=mappings_extractor,
    input= combined_text, 
    description=f"""
You are tasked with extracting mappings for **survey details** (e.g., surveyor name, survey date, location address) using a **controlled vocabulary** approach.

Use the Controlled Vocabulary below to match fields present in the document:

{json.dumps(controlled_vocabulary, indent=2)}

### Scope of Work:
- Identify survey metadata fields such as:
  - Surveyor Name
  - Survey Date
  - Report Date (only if specifically requested)
  - Location Name
  - Location Address

### Mapping Instructions:
- **Controlled Vocabulary Match**: Match fields only to terms from the Controlled Vocabulary provided.
- **Semantic Awareness**: Consider synonyms and document-specific terminology (e.g., “Prepared by” → “Surveyor Name”).
- **Avoid Wrong Assumptions**: If unsure about the correct mapping, list the field in the `ambiguous_fields` section with a justification.
- **Comment Clarity**: Add a note explaining why a match was made — e.g., "Matched 'Date Visited' to 'Survey Date' because it's when the inspection occurred."

### Matching Rules:
- **Case-insensitive**
- **No noisy data** outside controlled terms
- **No speculative matches** — err on the side of caution
- **Ambiguity > Assumption**

### Output MUST Be:
- Reliable
- Traceable
- Controlled
- Easily auditable

""",
    expected_output="""
{
    "mappings": {
        "document_field_name": {
            "standard_field": "Controlled Vocabulary Field",
            "matched_by": "Exact Match / Synonym / Fuzzy Logic",
            "comment": "Explain why you matched it"
        }
    },
    "ambiguous_fields": {
        "document_field_name": "Reason for ambiguity"
    },
    "notes": "Any general observations or suggestions for Controlled Vocabulary improvements."
}
"""
)


survey_details_extraction_task = Task(
    name='Extraction of Survey Details',
    agent=survey_details_extractor,
    input= combined_text,
    description="""
🎯 Task Objective:
Extract precise metadata from a risk inspection or survey report. The fields required are:

1. **Name of the Surveyor**
   - 🔍 Definition: The full name of the person who physically visited or inspected the insured site. Often found near "Prepared By", "Surveyed By", or listed under "Team Members".
   - ⚠️ Do NOT extract company names unless the individual’s name is missing.

2. **Survey Date**
   - 🔍 Definition: The actual date the site was visited and inspected. This is different from the report creation or submission date.
   - ✅ Acceptable Phrases: "Date Visited", "Survey Date", "Inspection Date"
   - ❌ Avoid: "Report Date", "Date of Report Generation"

3. **Location Address**
   - 🔍 Definition: The full physical address of the **insured or surveyed location**.
   - ✅ Acceptable Labels: "Site Address", "Insured Location", "Survey Location", "Property Location", "Risk Location"
   - ❌ Reject Addresses labeled as: "Mailing Address", "Correspondence Address", "Broker/Agent Office", "Registered Office", "Billing Location"

4. **Location Name**
   - 🔍 Definition: The name of the site being surveyed, which could be the insured entity (e.g., "Cochin Port Trust") or a facility name (e.g., "Container Freight Station, Q4 Berth")
   - 🎯 This name helps identify the insured facility for linking survey metadata to underwriting records.

📌 Extraction Guidelines:
- Prefer values from structured headers or metadata sections.
- If multiple candidates exist, choose the most directly linked to the inspection activity.
- If a required field is **not present**, return `"Unknown"` as the value.

📦 Output Format:
Your final output must be structured, complete, and clearly labeled, like this:

{
    "Name of the Surveyor": "Shubham Gupta",
    "Survey Date": "21-JUN-2019",
    "Location Address": "Willingdon Island, Cochin, Kerala",
    "Location Name": "Cochin Port Trust"
}
""",
    expected_output="""
{
    "Name of the Surveyor": "String",
    "Survey Date": "String",
    "Location Address": "String",
    "Location Name": "String"
}
"""
)

construction_management_extraction_task = Task(
    name='Extraction of Risk Assessment Grades and Comments',
    agent=construction_management_extractor,
    input= combined_text,
    description="""
🎯 Task Objective:
Extract clearly stated assessment grades and relevant comments from a risk inspection report. The required fields are:

1. **Construction Grade**
   - 🔍 Definition: A formal classification of the site's construction type or risk level.
   - ✅ Acceptable Labels: "Marginal", "Excellent", "Good", "Average", "Poor" etc.
   - ⚠️ Only extract if the grade is explicitly stated (do not infer).

2. **Construction Comments**
  - 🔍 Definition: Narrative description or evaluation related to the site's construction type, building structure, and fire-related characteristics.
  - 🧱 Must include:
      - Quality and type of construction materials used (e.g., brick, concrete, steel, wood)
      - Structural layout and materials mentioned under sections like "Buildings", "Properties", or "Structures"
      - Fire resistance characteristics (e.g., RCC slabs, fire-rated doors, compartmentalization)
      - Features relevant to fire prevention or mitigation (e.g., open yard spacing, firewall separations)
      - Installations that can influence fire risk: electrical wiring, boiler rooms, transformers, etc.
  - ✅ Acceptable Sources:
      - "Construction Summary"
      - "Fire Risk / Fire Spread Prevention"
      - "Electrical Installations", "Power Equipment"
      -  detailed site layout descriptions
  - ⚠️ Avoid:
      - Comments that describe only occupancy usage (e.g., storage or operations)
      - Vague or speculative assumptions (e.g., “likely fireproofed”)
  - 🎯 Purpose:
      - To explain why a particular Construction Grade has been assigned
      - To support risk underwriting and fire prevention evaluation

3. **Management Grade**
   - 🔍 Definition: A formal maturity rating applied to the site’s management programs (e.g., maintenance, safety, response).
   - ✅ Acceptable Labels: "Marginal", "Excellent", "Good", "Average", "Poor" etc.
   - ⚠️ Only extract if the maturity level is clearly defined in the document.

4. **Management Comments**
  - 🔍 Definition: Contextual explanation or justification for the management grade, based on the site's programs, systems, and practices for safety, loss prevention, and emergency preparedness.
  - 🧩 Must include:
      - Safety management measures (e.g., use of SOPs, checklists, audit protocols)
      - Loss prevention strategies and programs implemented on site
      - Disaster prevention organization structure (roles, responsibilities, escalation protocols)
      - Regulatory compliance efforts (e.g., routine testing, documentation practices)
      - Education and training initiatives for emergency handling (e.g., mock drills, firefighting training, employee certification)
  - ✅ Acceptable Sources:
      - “Management Programs”
      - “Risk Observations”
      - “Emergency Response Plans”
      - “Training Logs” or similar operational records
  - ⚠️ Avoid:
      - Comments focused only on hardware (e.g., extinguishers, hydrants — unless linked to management practices)
      - Generic language that does not explain grade rationale
  - 🎯 Purpose:
      - To justify the assigned Management Grade through observed practices and program maturity
      - To assess readiness and accountability at an organizational level

📌 Extraction Guidelines:
- Do NOT guess or interpret implied meaning — grades must be **explicitly written**.
- Comments must reflect the rationale or qualitative judgment for the grade.
- If any required field is missing from the document, return it as `"Unknown"`.

📦 Output Format:

{
    "Construction Grade": "Average",
    "Construction Comments": "Site is benefitted with majorly non-combustible construction with RCC structure...",
    "Management Grade": "Average",
    "Management Comments": "The inspection, testing and maintenance for cargo handling equipment is embedded with checklists derived from OEM recommendations..."
}

""",
    expected_output="""
{
    "Construction Grade": "String",
    "Construction Comments": "String",
    "Management Grade": "String",
    "Management Comments": "String"
}
"""
)

occupation_protection_extraction_task = Task(
    name='Extraction of Occupation and Protection Grades and Comments',
    agent=occupation_protection_extractor,
    input= combined_text,
    description="""
🎯 Task Objective:
Extract clearly defined assessment grades and supporting commentary related to **Occupation** and **Protection** from a risk inspection report.

🧩 Required Fields:

1. **Occupation Grade**
   - 🔍 Definition: A formal classification of how the site is used and the associated risk class (e.g., storage, manufacturing, hazardous).
   - ✅ Acceptable Labels: "Marginal", "Excellent", "Good", "Average", "Poor" etc.
   - ⚠️ Only extract if explicitly stated as a grade, category, or label.

2. **Occupation Comments**
    - 🔍 Definition: Descriptive overview of how the risk location is functionally utilized, including the type of operations performed, materials handled, occupancy characteristics, and fire hazard mitigation measures in place.
    - 🧩 Must include:
        - Purpose of use: factory, production unit, storage/warehouse, office, administrative center, etc.
        - Number of persons typically working or residing at the location (if specified)
        - Operational processes and their associated risks (e.g., welding, chemical handling, spice drying, etc.)
        - Inventory type and storage practices (e.g., flammable vs. non-flammable goods, vertical stacking, segregation)
        - Fire load management: tidiness, spatial layout, accessibility of exits
        - Maintenance of equipment/processes to reduce ignition risk (e.g., dust removal, machine servicing)
    - ✅ Source Sections:
        - “Occupancy and Process”
        - “Key Features/Processes”
        - “Fire Load Management”, “Inventory Observations”
    - ⚠️ Avoid:
        - Comments that just restate the construction or protection details
        - High-level generalizations without specific site-linked context
    - 🎯 Purpose:
        - To explain how the site's function contributes to fire risk or operational vulnerability
        - To justify the assigned Occupation Grade (e.g., Low Hazard, Storage, Manufacturing)


3. **Protection Grade**
   - 🔍 Definition: A formal rating or judgment on the adequacy of fire protection measures (active and passive).
   - ✅ Acceptable Labels: "Marginal", "Excellent", "Good", "Average", "Poor" etc.
   - ⚠️ Only extract if explicitly labeled or clearly scored.

4. **Protection Comments**
  - 🔍 Definition: Supporting explanation and observations on the fire protection systems and safety measures implemented at the risk location, based on documented infrastructure and surveyor assessments.
  - 🧯 Must include:
      - On-site firefighting equipment: fire extinguishers, hydrants, hose reels, sprinkler systems, detection/alarm systems
      - Description of operational condition and placement of protection systems
      - Active vs. passive fire safety features (e.g., smoke alarms vs. compartmentation)
      - Surveyor remarks on adequacy, coverage gaps, or malfunctioning equipment
      - Details on protection from external or public fire services (e.g., nearest fire station, response time)
      - Presence of emergency response programs and drills, if related to fire safety
  - ✅ Source Sections:
      - “Fire Protection”
      - “Site Protection”
      - “Sprinkler Systems”
      - “Water Supply Details”
      - “Surveyor Observations”
  - ⚠️ Avoid:
      - Generic statements about “adequate protection” unless elaborated
      - Non-fire protection topics like safety signage or exit paths (unless linked to suppression/control)
  - 🎯 Purpose:
      - To justify the assigned Protection Grade by clearly describing the level and condition of implemented fire protection infrastructure
      - To help assess the site's capacity to suppress or respond to fire-related incidents


📌 Guidelines:
- Do not infer any grade unless it's explicitly labeled.
- Extract adjacent or relevant commentaries in full sentences or concise summaries.
- If a value is not mentioned in the document, return `"Unknown"`.

📦 Output Format:

{
    "Occupation Grade": "Average",
    "Occupation Comments": "CFS warehouse is used primarily for spice and cargo storage with no manufacturing activities.",
    "Protection Grade": "Average",
    "Protection Comments": "There are no sprinkler systems or fire detection mechanisms in the CFS warehouse; only hydrants are present in limited zones."
}

""",
    expected_output="""
{
    "Occupation Grade": "String",
    "Occupation Comments": "String",
    "Protection Grade": "String",
    "Protection Comments": "String"
}
"""
)

exposure_overall_extraction_task = Task(
    name='Extraction of Exposure and Overall Risk Grades and Comments',
    agent=exposure_overall_extractor,
    input= combined_text,
    description="""
🎯 Task Objective:
Extract exposure-related and overall site-level risk assessments from a formal insurance or engineering risk inspection report.

🧩 Required Fields:

1. **Exposure Grade**
   - 🔍 Definition: An explicitly stated grade or label indicating the site's exposure to natural or external hazards (e.g., storm surge, flooding, earthquake, tsunami).
   - ✅ Acceptable Labels: "Marginal", "Excellent", "Good", "Average", "Poor" etc.
   - ⚠️ Only extract if explicitly present (e.g., within tables, FM Global/Nathan ratings, or labeled zones)

2. **Exposure Comments**
  - 🔍 Definition: Descriptive analysis of the site's exposure to natural and external hazards, including environmental risks, geographic vulnerabilities, and the site's proximity to external threats.
  - 🌍 Must include:
      - Exposure to natural hazards: flood risk, storm surge, proximity to water bodies, lightning-prone zones, wind zone, seismic zone, tsunami zones
      - External fire exposures: risk of fire spread from adjacent structures, chemical storage yards, tank farms, slums, or other fire-prone areas
      - Nat-Cat preparedness measures: flood defenses, elevated construction, emergency response planning for natural disasters
      - Access and proximity to public fire services (e.g., nearest fire station distance, response time)
      - Terrain features: slope, drainage capability, coastline vulnerability
  - ✅ Source Sections:
      - “Site Characteristics and Exposures”
      - “Natural Hazard Ratings”
      - “Risk Overview” or “External Exposure” sections
  - ⚠️ Avoid:
      - Internal construction/protection features (unless directly linked to mitigating external risks)
      - Generic environmental context without direct linkage to exposure grading
  - 🎯 Purpose:
      - To justify the assigned Exposure Grade through contextually grounded environmental and geographic observations
      - To highlight the site's vulnerability to natural or external events that may impact insurability or risk engineering

3. **Overall Grade**
   - 🔍 Definition: An explicitly stated final or summary grade for the site's overall risk profile.
   - ✅ Acceptable Labels: "Marginal", "Excellent", "Good", "Average", "Poor" etc.
   - ⚠️ Must be clearly labeled — do not infer.

4. **Overall Comments**
   - 🔍 Definition: Narrative evaluation summarizing key risks, strengths, vulnerabilities, and general loss potential.
   - ✅ Source Sections: "Risk Observations and Comments","Executive Summary", "Summary", "Conclusion", "Loss Estimate Overview"

📌 Guidelines:
- Only include grades that are clearly marked or scored.
- Include full, relevant explanatory text for comments.
- Return `"Unknown"` if a value is not stated or clearly inferable from the report.

📦 Output Format:

{
    "Exposure Grade": "Average",
    "Exposure Comments": "Site is exposed to 500-year return period storm surge per Nathan report, and faces river flood hazard due to proximity to Ernakulam channel.",
    "Overall Grade": "Average",
    "Overall Comments": "Fire in CFS warehouse poses major risk due to lack of fire detection/protection; however, site construction and compartmentalization are otherwise favorable."
}

""",
    expected_output="""
{
    "Exposure Grade": "String",
    "Exposure Comments": "String",
    "Overall Grade": "String",
    "Overall Comments": "String"
}
"""
)

recommendations_and_improvements_extraction_task = Task(
    name='Extraction of Improvements and Urgent Recommendations',
    agent=recommendations_and_improvements_extractor,
    input= combined_text,
    description="""
🎯 Task Objective:
From the risk inspection report, extract the following:

1. **Improvements from Previous Survey**
   - 🔍 Definition: Any clearly stated upgrades, actions, or fixes implemented since the last inspection.
   - ✅ Acceptable Phrases: "Since the last visit...", "In response to the previous report...", "As recommended earlier..."
   - ✅ Also look for section titles like "Changes since last survey", "Previous observations addressed"
   - ❌ Avoid vague or unconfirmed observations — only extract improvements that are explicitly reported.

2. **Important/Urgent Recommendations**
   - 🔍 Definition: Recommendations that are flagged as high priority by the surveyor, or contain urgency for remediation.
   - ✅ Acceptable Phrases: "It is strongly recommended...", "Urgent action should be taken...", "This should be implemented without delay", "High priority"
   - ✅ Source Sections: "Risk Observations", "Recommendations", "Surveyor Comments", "Summary of Findings"
   - ❌ Do not include general observations or non-actionable text.

📌 Guidelines:
- Return the most relevant sentences or bullet points, not entire sections.
- If there are no stated improvements or urgent recommendations, return `"Unknown"` for those fields.

📦 Output Format:

{
    "Improvements from Previous Survey": "The client has implemented regular thermographic inspections since the last survey, as previously advised.",
    "Important/Urgent Recommendations": "Installation of sprinkler system in CFS warehouse is strongly recommended due to high fire exposure and lack of existing protection."
}

""",
    expected_output="""
{
    "Improvements from Previous Survey": "String",
    "Important/Urgent Recommendations": "String"
}
"""
)


# Define the Crew workflow
"""
crew = Crew(
    agents=[
        mappings_extractor,
        survey_details_extractor, 
        construction_management_extractor, 
        occupation_protection_extractor, 
        exposure_overall_extractor, 
        recommendations_and_improvements_extractor
    ],
    tasks=[
        survey_details_mapping_task, 
        survey_details_extraction_task, 
        construction_management_extraction_task, 
        occupation_protection_extraction_task,
        exposure_overall_extraction_task, 
        recommendations_and_improvements_extraction_task
    ],
    verbose=True,
    process=Process.sequential,
    manager_llm=llm
)

# Kick off the workflow
result = crew.kickoff()

print(result) """

def run_task(task, agent):
    crew = Crew(
        agents=[agent],
        tasks=[task],
        verbose=True,
        process=Process.sequential,
        manager_llm=llm
    )
    return crew.kickoff()

survey_details_mapping_result = run_task(survey_details_mapping_task, mappings_extractor)
survey_details_extraction_result = run_task(survey_details_extraction_task, survey_details_extractor)
construction_management_result = run_task(construction_management_extraction_task, construction_management_extractor)
occupation_protection_result = run_task(occupation_protection_extraction_task, occupation_protection_extractor)
exposure_overall_result = run_task(exposure_overall_extraction_task, exposure_overall_extractor)
recommendations_result = run_task(recommendations_and_improvements_extraction_task, recommendations_and_improvements_extractor)

final_output = {}

# Directly merge the results (since they are already in JSON format)
final_output.update(survey_details_mapping_result)
final_output.update(survey_details_extraction_result)
final_output.update(construction_management_result)
final_output.update(occupation_protection_result)
final_output.update(exposure_overall_result)
final_output.update(recommendations_result)

# Optionally, print a message if any result was empty or failed
# This step assumes that you want to track if any task returned an empty result.
for section_name, result in [
    ("survey_details_mapping", survey_details_mapping_result),
    ("survey_details_extraction", survey_details_extraction_result),
    ("construction_management", construction_management_result),
    ("occupation_protection", occupation_protection_result),
    ("exposure_overall", exposure_overall_result),
    ("recommendations", recommendations_result),
]:
    if not result:
        print(f"⚠️ No valid result from {section_name}")

with open("prelim_result.json", "w") as f:
    json.dump(final_output, f, indent=2)

revalidation_task = Task(
    name='Validate Final Extraction Accuracy Against Source Document',
    agent=revalidation_agent,
    input={
        "extracted_data": final_output,
        "source_text": combined_text
    },
    description="""
🎯 Task Objective:
Validate whether the extracted data fields from a risk inspection report are accurate, faithful, and fully verifiable against the original text.
You are given:
- A dictionary of extracted fields and values
- The full combined text of the document(s)
Your job:
- Compare each extracted value to the source document
- Confirm whether it exists and is correctly interpreted
- Flag anything missing, hallucinated, or semantically misaligned
✅ Output MUST include:
1. Accuracy Score (0 to 100)
2. Mismatched Fields (list with reasons)
3. Validation Notes (how to improve accuracy or fix common issues)
""",
    expected_output="""
{
    "accuracy_score": 0-100,
    "mismatched_fields": {
        "field_name": "Reason it was flagged or why it doesn't match the source"
    },
    "validation_notes": "Suggestions for improving extraction consistency or robustness"
}
"""
)

validation_crew = Crew(
    agents=[revalidation_agent],
    tasks=[revalidation_task],
    verbose=True,
    process=Process.sequential,
    manager_llm=llm
)

validation_result = validation_crew.kickoff()
parsed_validation_result = extract_json_from_agent_output(validation_result)

# ------------------- Save Results -------------------
with open("validation_result.json", "w") as f:
    json.dump(parsed_validation_result, f, indent=2)

print("\n✅ Final Output:")
print(json.dumps(final_output, indent=2))

print("\n🧪 Validation Summary:")
print(json.dumps(parsed_validation_result, indent=2))
