from crewai import Crew,Process 
from agents import coverage_type_extraction_agent,loss_extraction_agent
from tasks import coverage_type_extraction_task,loss_extraction_task

crew = Crew(
	agents = [coverage_type_extraction_agent,loss_extraction_agent],
	tasks = [coverage_type_extraction_task,loss_extraction_task],
	process = Process.sequential,
	memory = True,
	cache = True,
	max_rpm = 100,
	share_crew = True
)

result = crew.kickoff()
print(result)