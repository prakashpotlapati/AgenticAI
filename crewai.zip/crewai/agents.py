from crewai import Agent,LLM
# from tools import tool


os.environ["GROQ_API_KEY"] = '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'
groq_llm = LLM(model="groq/llama-3.3-70b-versatile")
# loss data extraction agent from text 

def read_text(file_name):
	with open(file_name, 'r') as file:
	content = ''
    for line in file:
        content += line
        content += '\n'

    return content 


# content = read_text('test.txt')

coverage_type_extraction_agent = Agent(

	role = "Extract the coverage type,currency,insured name,period present in the given text",
	goal = "Get accurate coverage type, currency , insured name,period with enough confidence score",
	verbose = True,
	memory = True,
	backstory = (
		"Expert in finding the appropriate coverage type, currency , insured name , period in the given text"
	),
	allow_delegation = True
)

loss_extraction_agent = Agent(

	role = 'Extract Relevant data from provided text',
	goal = 'Get all the relevant data present in text',
	verbose = True,
	memory = True,
	backstory = (
		"Expert in extraction tabular data present in textual format"
	),
	allow_delegation = False
)


