from crewai_tools import TXTSearchTool 


tool = PDFSearchTool(
    config=dict(
        llm=dict(
            provider="openai",  # Groq uses OpenAI-compatible API
            config=dict(
                model="mixtral-8x7b-32768",  # or "llama2-70b-4096"
                base_url="https://api.groq.com/openai/v1",
                api_key= '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',
                # Set this environment variable
                # temperature=0.5,
                # max_tokens=4096,
            ),
        ),
        embedder=dict(
            provider="google",  # Keep using Google for embeddings
            config=dict(
                model="models/embedding-001",
                task_type="retrieval_document",
            ),
        ),
    )
)