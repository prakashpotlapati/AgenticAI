from crewai import Agent, Task, Crew, LLM
import os
import json
from prompts import prompt,coverage_type_prompt,expected_out,coverage_type_expected_out
from crewai.tools import tool




os.environ["GROQ_API_KEY"] = "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"
groq_llm = LLM(model="groq/llama-3.3-70b-versatile")



# Tools
@tool("File Reader Tool")
def file_reader(file_path: str) -> str:
    """Reads text files"""
    with open(file_path, 'r') as file:
        return file.read()

@tool("Excel Reader Tool")
def excel_reader(file_path: str) -> str:
    """Reads Excel files as CSV"""
    try:
        import pandas as pd
        df = pd.read_excel(file_path)
        return df.to_csv(index=False)
    except Exception as e:
        return f"Error reading Excel: {e}"

# Agents
coverage_agent = Agent(
    role='Insurance Coverage Specialist',
    goal='Extract key coverage details from policies',
    backstory="Experienced insurance policy analyst with legal background",
    tools=[file_reader],
    llm=groq_llm,
    verbose=True
)

data_analyst_agent = Agent(
    role='Risk Data Analyst',
    goal='Analyze risk data in context of coverage details',
    backstory="Financial risk analyst specializing in insurance metrics",
    tools=[excel_reader],
    llm=groq_llm,
    verbose=True
)

# Tasks
coverage_extraction_task = Task(
    description=coverage_type_prompt(),
    expected_output=coverage_type_expected_out(),
    agent=coverage_agent,
    output_file="coverage_results.json"
)

data_analysis_task = Task(
    # description=lambda context: prompt(context['coverage_info']),

    # description = lambda context: prompt(context['coverage_info']),
    description = """
        You are an advanced property insurance agent, with understanding for insurance terms like claims, premiums etc. Your task is to extract premium
    , claim and total sums insured values which are numeric values.

         --> Extract the data if they are only under Loss Section, Loss history section.
         --> If you are not confident with loss years then don't extract.
        
        DATA EXTRACTION GUIDELINES:
            1. Extract only numeric values. Zeros and negative numbers are also valid values.
            2. Ensure negative values are retained as they appear.
            3. Do not consider TSI values.
            4. Avoid summing or aggregating values for premium, claims, and total sum insured. Keep individual entries distinct and separate and create a list.
            5. For each of the keys there may exist more than one value, Make a list of all the values that satisfy the conditions given below.
            6. Consider negative values also donot omit them.
 
        Task 1 : Filtering based on Year:
            1. Use the 'Policy Start date' as the year reference.
            2. Only include the data between {data['Year']}-4 to {data['Year']} in the start data of policy or uw year.
            3. If data for a specific year in the range is not available do not mention that year in output.
            
        Task 2 : Filtering based on contract type code: 1. **the contract type should exactly match any of the following: {data['Insurance Type']}**. 
        Example: From the data below:
        Year | Contract Code Type | Premium | Claim | Coverage Amount
        2980 | IAR | 100 | 200 | 300 
        2980 | PAR | 100 | 150 | 250 
        2980 | EAQ | 400 | 700 | 1000 
        2980 | MCB | 550 | 650 | 750 
        
        if the only desired list is IAR,EAQ and MCB you should only consider them and discard PAR row.

        Task 3 : Filtering based on the insured name. 

        Filter based on insured name only which matches in {data['Insured Name']}.
        
        Task 4: Data Extraction and mapping
           Extract the data by identifying relevant financial values under specific categories. Ensure all extracted values are stored in arrays to account for multiple occurrences or multiple rows that satisfy the criterion. Ensure to capture all the values that satisfy the conditions, do not just pick the first value, Go through the data and pick all the values that satisfy the conditions Follow the selection priorities and exclusions strictly.
Keys and Extraction Rules:

3.1 Total Sum Insured (total_sums)
    Coverage Amount is total sums insured values. Any Total Sum Insured or coverage amount values (not related to premiums) should be listed under the "total_sums" key. Extract all values under column headers similar to:
     "Insured Amount",
        "Coverage Amount (100%) (<placeholder value>)",
     "Sum Insured (100%) (<placeholder value>)"
     Any other title that indicates "Coverage Amount" or "Sum Insured".
    
    Selection Priorities:
     
    column with title that indicates "Coverage Amount" or "Sum Insured"
     
    "Coverage Amount (100%) (<placeholder value>)" or "Sum Insured (100%) (<placeholder value>)"
     
    Coverage Amount is considered as total sum Insured.

     Insured Amount is considered as total sum insured.
    
    Exclusions:
    Do not extract from headers containing "Gross Premium", "Net Premium", "GWP Earned Aft Co-Out".

3.2 Premium Values (premium):
    Extract all values from column headers explicitly mentioning "Premium":
    "Premium (100%) (CNY) (Tax Included)"
    "Net Premium 100%"
    "GWP Earned Aft Co-Out"
    
    Selection Priorities:
    If both "Net Premium" and "Gross Premium" exist, choose "Net Premium".
    "GWP Earned Aft Co-Out" is considered as premium value.
    Ignore any fields labeled "Sum Item: Premium".
    If the provided text contains multiple values, ensure that all values are identified and extracted, organizing them in JSON format for structured output.

3.3 Claim Values (claim):
    Extract all values under column headers related to claims, such as:
    "Compensation Amount"
    "100% Paid Expenses (Orig Curr)"
    "Gross Incurred Claims"
    "Claims Incurred Aft Co-Out"
    Any column labeled "Amount" (only if related to claims).
    
    Selection Priorities:
    If both "Gross Incurred Claims" and "Gross Paid Claims" exist, choose "Gross Paid Claims".
    
    Exclusions:
    Ignore columns containing "Sum of claim".

If the claim value convert it from {data['Currency']} into USD and if it is greater than 25K USD or less that -25K USD then extract the description of loss. And put under "Majorloss_comments" yearwise in the output json.

3.4 Outstanding Claims (os):
    Extract only from columns explicitly mentioning "Outstanding Claims".
    Exclusions:
    Do not include sum or cumulative values.

3.5 Rate Values (rate):
    Identify rate values expressed in percentage format.
    Ensure each extracted rate is associated with the respective year if available.
3.6 Evaluated As Of (Date): 
    Identify the evaulated as of date in the text for loss records/loss claims.

Output Format:
                    {{'2020': {{'premium': [value1,value2...],
                      'claim': [value1,value2...],
                      'os': [value1,value2...],
                      'total_sums': [value1,value2...],
                      'total_claim': [value1,value2...],
                      'major_loss' : [Major loss if the value of claim is greater than 25k USD only if the year has a claim > 25k usd],
                      'Evaluated_asof' : <Date of evaluation for loss records>,
                      'jusification' : <From where the data is primarily collected>
                      }},
                     '2021': {{'premium': [value1,value2...],
                      'claim': [value1,value2...],
                      'os': [value1,value2...],
                      'total_sums': [value1,value2...],
                      'total_claim': [value1,value2...]}},
                      'major_loss' : [Major loss if the value of claim is greater than 25k USD only if the year has a claim value > 25k usd],
                       'Evaluated_asof' : <Date of evaluation for loss records>,
                       'jusification' : <From where the data is primarily collected>
                      }}

Guidelines:
Ensure extracted values are properly formatted (e.g., numbers without additional text or symbols).
Preserve numerical precision while extracting values.
Follow selection priorities strictly.
 
 
 SAMPLE EXAMPLE:
 
  SAMPLE INPUT:
 
            Year | Contract Code Type | Premium | Claim | Coverage Amount
 
            2990 | IAR | 100 | 200 | 300
            2990 | PAR | 100 | 150 | 250
            2990 | EAQ | 400 | 700 | 1000
            2990 | MCB | 550 | 650 | 750
 
     Desired list is IAR,EAQ and MCB
 
  
  SAMPLE OUTPUT:

      {{
                        2990 : {{
                                    'premium' : [100,400,550],
                                    'claim' : [200,700,650],
                                    'total_sum' : [300,1000,750],
                                    'os' : [],
                                    'rate' : [],
                                    'major_loss' : [],
                                    'Evaluated_asof' : ''
                                    
                                }}
                    }}
 
                  
 
            
    """,
    expected_output=expected_out(),
    agent=data_analyst_agent,
    context=[coverage_extraction_task],
    output_file="data_analysis.json"
)

# Crew
# insurance_crew = Crew(
#     agents=[coverage_agent, data_analyst_agent],
#     tasks=[coverage_extraction_task, data_analysis_task],
# )

def analyze_insurance_data(text_path: str, excel_path: str):
    # Execute coverage extraction
    coverage_result = coverage_agent.execute_task(coverage_extraction_task,context={"file_path": text_path})
    
    try:
        data = json.loads(coverage_result)
    except json.JSONDecodeError as e:
        raise ValueError(f"Failed to parse coverage data: {str(e)}")


    # Execute data analysis with actual coverage info
    analysis_result = data_analyst_agent.execute_task(data_analysis_task,context={
        "excel_file_path": excel_path,
        "coverage_info": data
    })

    return {
        "coverage_info": data,
        "analysis_result": json.loads(analysis_result)
    }

if __name__ == "__main__":
    text_file = "test.txt"
    excel_file = "data.xlsx"

    try:
        results = analyze_insurance_data(text_file, excel_file)
        
        print("\n=== Coverage Details ===")
        print(json.dumps(results['coverage_info'], indent=2))
        
        print("\n=== Risk Analysis ===")
        print(json.dumps(results['analysis_result'], indent=2))
        
    except Exception as e:
        print(f"\nERROR: {str(e)}")